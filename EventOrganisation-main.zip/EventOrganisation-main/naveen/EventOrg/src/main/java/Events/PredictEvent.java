package Events;

import java.io.IOException;
import java.io.PrintWriter;

//import javax.activation.DataSource;
import javax.servlet.RequestDispatcher;
import javax.servlet.ServletConfig;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import weka.classifiers.Classifier;
import weka.classifiers.bayes.NaiveBayes;
import weka.core.DenseInstance;
import weka.core.Instance;
import weka.core.Instances;
import weka.core.converters.ConverterUtils.DataSource;

@WebServlet("/PredictEvent")
public class PredictEvent extends HttpServlet 
{
	private static final long serialVersionUID = 1L;
    public PredictEvent() 
    {
        super();
    }
	public void init(ServletConfig config) throws ServletException 
	{
		
	}
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException 
	{
		response.getWriter().append("Served at: ").append(request.getContextPath());
	}
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException 
	{
		String date = request.getParameter("date");
		String location = request.getParameter("location");
		String description = request.getParameter("description");
		response.setContentType("text/html");
		PrintWriter out = response.getWriter();
		try
		{
			String path = getServletContext().getRealPath("/WEB-INF/events.arff");
			DataSource source = new DataSource(path);
			Instances data = source.getDataSet();

			data.setClassIndex(data.numAttributes() - 1);

			Classifier classifier = new NaiveBayes();
			classifier.buildClassifier(data);

            Instance newEvent = new DenseInstance(data.numAttributes());
            newEvent.setDataset((Instances) data);
            newEvent.setValue(data.attribute("location"), location);
            newEvent.setValue(data.attribute("date"), date);
            newEvent.setValue(data.attribute("description"), description);

            double predIndex = classifier.classifyInstance(newEvent);
            String prediction = data.classAttribute().value((int) predIndex);

            request.setAttribute("prediction", prediction);
            RequestDispatcher rd = request.getRequestDispatcher("PredictResult.jsp");
            rd.forward(request, response);
		}
		catch(Exception obj)
		{
			obj.printStackTrace();
		}
	}

}
