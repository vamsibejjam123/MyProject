package Events;

import java.io.IOException;
import java.io.PrintWriter;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

@WebServlet("/NewEvent")
public class NewEvent extends HttpServlet 
{
	private static final long serialVersionUID = 1L;

    public NewEvent() 
    {
        super();
    }
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException 
	{
		response.getWriter().append("Served at: ").append(request.getContextPath());
	}
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException 
	{
		try
		{
			String Organiser_name = request.getParameter("on");
			String Mobile_number = request.getParameter("mn");
			String event_name = request.getParameter("en");
			String location = request.getParameter("location");
			String time = request.getParameter("time");
			String dob = request.getParameter("dob");
			String mail = request.getParameter("email");
			if(!Organiser_name.isEmpty()||!Mobile_number.isEmpty()||!event_name.isEmpty()||!location.isEmpty()||!time.isEmpty()||!dob.isEmpty()||!mail.isEmpty())
			{
				if(emailverification(mail)==true)
				{
					try
					{
						Class.forName("com.mysql.cj.jdbc.Driver");
						Connection con = DriverManager.getConnection("jdbc:mysql://localhost:3306/Event","root","Welcome@123");
						PreparedStatement ps = con.prepareStatement("insert into events(name,mobile_number,Event_name,location,booking_time,booking_date,email) values(?,?,?,?,?,?,?)");
						ps.setString(1, Organiser_name);
						ps.setString(2, Mobile_number);
						ps.setString(3, event_name);
						ps.setString(4, location);
						ps.setString(5, time);
						ps.setString(6, dob);
						ps.setString(7, mail);
						ps.executeUpdate();
						RequestDispatcher rd = request.getRequestDispatcher("BookedEvent.html");
						rd.forward(request, response);
					}
					catch(Exception obj)
					{
						obj.printStackTrace();
					}
				}
				else
				{
					String m = "Please Enter Valid E-mail Adress";
					PrintWriter out = response.getWriter();
					out.println(m);
					response.setContentType("text/html");
					out.println("<html> <body> <a href='NewEvent.html'>Go Back</a> </body> </html>");
				}
			}
			else
			{
				String m = "Some fields are missing";
				PrintWriter out = response.getWriter();
				out.println(m);
				response.setContentType("text/html");
				out.println("<html> <body> <a href='NewEvent.html'>Go Back</a> </body> </html>");
			}
		}
		catch(Exception obj)
		{
			obj.printStackTrace();
		}
	}
	private boolean emailverification(String s) 
	{
		int y = s.indexOf("@");
		int u= s.indexOf("@",y+1);
		int p= s.lastIndexOf("@",y-1);
		String errorM = "";
		if(p==-1&&u==-1&&y!=-1&&s.length()>=15&&s.length()<=50)
		{
		    if(!Character.isUpperCase(s.charAt(0)))
    		  {
    		      return false;
    		  }
    	    if(!Character.isLetter(s.charAt(y-1))&&!Character.isDigit(s.charAt(y-1)))
    		  {
    		      return false; 
    		  }
    		if(errorM.isEmpty()) 
    		{
        		for(int i=1;i<y-1;i++)
        		{
        		    if(!Character.isLetter(s.charAt(i))&&!Character.isDigit(s.charAt(i)))
        		    {
        		        if(s.charAt(i)!='.'&&s.charAt(i)!='_')
        		        {
        		            return false;
        		        }
        		    }
        		}
        		for(int i=y+1;i<s.length();i++)
        		{
        		    if(Character.isDigit(s.charAt(i)))
        		    {
        		        return false;
        		    }
        		    else if(!Character.isLetter(s.charAt(i))&&(s.charAt(i)!='.'))
        		    {
        		        return false;
        		    }
        		}
    		}
    		if(errorM.isEmpty())
    		{
    		    return true;
    		}
    		else
    			return false;
		}
		else
			return false;
	}
}
