package Events;

import java.io.IOException;
import java.io.PrintWriter;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

@WebServlet("/login")
public class login extends HttpServlet 
{
	private static final long serialVersionUID = 1L;
    public login() 
    {
        super();
    }
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException 
	{
		response.getWriter().append("Served at: ").append(request.getContextPath());
	}
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException 
	{
		String email = request.getParameter("email");
		String pass = request.getParameter("password");
		boolean bo=false;
		try 
		{
			Class.forName("com.mysql.cj.jdbc.Driver");
			Connection con1=DriverManager.getConnection("jdbc:mysql://localhost:3306/Event","root","Welcome@123");
			PreparedStatement ps=con1.prepareStatement("select * from event");
			ResultSet rs=ps.executeQuery();
			while(rs.next()) 
			{
				String validemail=rs.getString(6);
				String validpassword=rs.getString(4);
				if(email.equals(validemail) && pass.equals(validpassword))
				{
					bo=true;
					break;
				}
			}
			if(bo==true) 
			{
				HttpSession user = request.getSession(true);
				user.setAttribute("email", email);
				user.setAttribute("pass", pass);
				RequestDispatcher rd = request.getRequestDispatcher("welcome.html");
				rd.include(request, response);
			}
			else
			{
				String m = "Please Enter Valid Login Credentials";
				PrintWriter out = response.getWriter();
				out.println(m);
				response.setContentType("text/html");
				out.println("<html> <body> <a href='Login.html'>Go Back</a> </body> </html>");
			}
		}
		catch(Exception obj)
		{
			obj.printStackTrace();
		}
	}

}
